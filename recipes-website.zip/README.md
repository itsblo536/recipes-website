# Recipes-Website

This project is a Recipes Website that allows a user to create and view recipes.
Users will be able to view all of the recipes they have created, along with the
recipe title, cooking time, ingredients, as well as instructions. The website also
has a Google Authentication System implemented to prevent users from being able to
view other users' created recipes.

# Github Repo
https://github.coecis.cornell.edu/bl536/Recipes-Website

# Delopyed Website
https://recipes-website-itsblo536.vercel.app/

# Group Members

Brendan Lo (bl536)

# Additional Info

My web app ended up being different from the one I proposed. I was initially going
to implement multiple pages, including one to view specific recipes and one to create
recipes. However, I found Chakra UI components being more aesthetically pleasing to 
view specific recipes. Additionally, I struggled a little implementing a separate create
page alone for the deadline, but I hope to be able to continue working on this over the summer!
